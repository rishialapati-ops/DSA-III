# Alumni Connect — Sample Text Corpus

This folder contains 100 fictional `.txt` documents for the Alumni Connect DSA project.

- **Purpose:** Demonstrate pattern searching over a corpus of text documents using the Knuth–Morris–Pratt (KMP) algorithm.
- **Location:** `data/alumni001.txt` through `data/alumni100.txt`
- **Content:** Sample education, professional experience, skills, and mentorship text.
- **Privacy:** All profiles are fictional demo data. They are not real people and are not verified alumni.
- **Usage:** Place this `data/` directory in the project root, alongside the `src/` directory.

Example search patterns: `Java`, `Python`, `KMP Algorithm`, `internship`, `Cloud Computing`.
